<?php
include 'conexion.php';

$email = strtolower(trim($_GET['email'] ?? ''));
if ($email === '') {
    responder(["ok" => false, "mensaje" => "Falta el email"], 400);
}

$st = preparar($conn, "SELECT id, intentos, segundos, fecha FROM partidas WHERE email = ? ORDER BY id DESC LIMIT 50");
$st->bind_param("s", $email);
$st->execute();

responder($st->get_result()->fetch_all(MYSQLI_ASSOC));
?>