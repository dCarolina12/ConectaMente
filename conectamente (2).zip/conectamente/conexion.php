<?php
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 0);     
mysqli_report(MYSQLI_REPORT_OFF);

$conn = @new mysqli("localhost", "root", "", "conectamente");
if ($conn->connect_errno) {
    responder(["ok" => false, "mensaje" => "No se pudo conectar a MySQL. ¿Está encendido en XAMPP?"], 500);
}
$conn->set_charset("utf8mb4");

function responder($datos, $codigo = 200) {
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE);
    exit;
}

function preparar($conn, $sql) {
    $st = $conn->prepare($sql);
    if (!$st) {
        responder(["ok" => false, "mensaje" => "Error en la base de datos. ¿Importaste las tablas?"], 500);
    }
    return $st;
}
?>