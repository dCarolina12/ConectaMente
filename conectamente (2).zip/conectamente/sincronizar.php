<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    responder(["ok" => false, "mensaje" => "Usa el método POST"], 405);
}

$datos = json_decode(file_get_contents('php://input'), true);
if (!is_array($datos) || empty($datos['email']) || empty($datos['usuario'])) {
    responder(["ok" => false, "mensaje" => "Faltan los datos del usuario"], 400);
}

$email   = strtolower(trim($datos['email']));
$usuario = trim($datos['usuario']);
$partidas = is_array($datos['partidas'] ?? null) ? $datos['partidas'] : [];
$animos   = is_array($datos['animos'] ?? null) ? $datos['animos'] : [];

$conn->begin_transaction();

// 1) Usuario: lo crea o actualiza su nombre
$st = preparar($conn, "INSERT INTO usuarios (email, usuario) VALUES (?, ?) ON DUPLICATE KEY UPDATE usuario = VALUES(usuario)");
$st->bind_param("ss", $email, $usuario);
if (!$st->execute()) {
    $conn->rollback();
    responder(["ok" => false, "mensaje" => "No se pudo guardar el usuario"], 500);
}

// 2) Partidas (INSERT IGNORE: si ya existe, no la duplica)
$partidasNuevas = 0;
$st = preparar($conn, "INSERT IGNORE INTO partidas (email, intentos, segundos, fecha) VALUES (?, ?, ?, ?)");
foreach ($partidas as $p) {
    $intentos = (int)($p['intentos'] ?? 0);
    $segundos = (int)($p['segundos'] ?? 0);
    $fecha    = substr((string)($p['fecha'] ?? ''), 0, 20);
    $st->bind_param("siis", $email, $intentos, $segundos, $fecha);
    $st->execute();
    if ($st->affected_rows > 0) $partidasNuevas++;
}

$animosNuevos = 0;
$st = preparar($conn, "INSERT IGNORE INTO animos (email, estado, fecha) VALUES (?, ?, ?)");
foreach ($animos as $a) {
    $estado = substr((string)($a['estado'] ?? ''), 0, 20);
    $fecha  = substr((string)($a['fecha'] ?? ''), 0, 20);
    $st->bind_param("sss", $email, $estado, $fecha);
    $st->execute();
    if ($st->affected_rows > 0) $animosNuevos++;
}

$conn->commit();

responder([
    "ok" => true,
    "mensaje" => "Datos sincronizados",
    "partidas_nuevas" => $partidasNuevas,
    "animos_nuevos" => $animosNuevos
]);
?>