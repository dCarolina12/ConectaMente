<?php
include 'conexion.php';

$email = strtolower(trim($_GET['email'] ?? ''));
if ($email === '') {
    responder(["ok" => false, "mensaje" => "Falta el email"], 400);
}

$st = preparar($conn, "SELECT id, email, usuario FROM usuarios WHERE email = ?");
$st->bind_param("s", $email);
$st->execute();
$usuario = $st->get_result()->fetch_assoc();

if (!$usuario) {
    responder(["ok" => false, "mensaje" => "Usuario no encontrado"], 404);
}

$st = preparar($conn, "SELECT COUNT(*) AS total, MIN(segundos) AS mejor_tiempo, MIN(intentos) AS menos_intentos FROM partidas WHERE email = ?");
$st->bind_param("s", $email);
$st->execute();
$p = $st->get_result()->fetch_assoc();

$st = preparar($conn, "SELECT COUNT(*) AS total FROM animos WHERE email = ?");
$st->bind_param("s", $email);
$st->execute();
$totalAnimos = (int)$st->get_result()->fetch_assoc()['total'];

$st = preparar($conn, "SELECT estado FROM animos WHERE email = ? ORDER BY id DESC LIMIT 1");
$st->bind_param("s", $email);
$st->execute();
$ultimo = $st->get_result()->fetch_assoc();

responder([
    "id" => (int)$usuario['id'],
    "email" => $usuario['email'],
    "usuario" => $usuario['usuario'],
    "total_partidas" => (int)$p['total'],
    "mejor_tiempo" => $p['mejor_tiempo'] !== null ? (int)$p['mejor_tiempo'] : null,
    "menos_intentos" => $p['menos_intentos'] !== null ? (int)$p['menos_intentos'] : null,
    "total_animos" => $totalAnimos,
    "ultimo_animo" => $ultimo ? $ultimo['estado'] : null
]);
?>