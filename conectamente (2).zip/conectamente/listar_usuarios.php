<?php
include 'conexion.php';

$sql = "SELECT u.id, u.email, u.usuario,
               (SELECT COUNT(*) FROM partidas p WHERE p.email = u.email) AS partidas,
               (SELECT COUNT(*) FROM animos a WHERE a.email = u.email) AS animos
        FROM usuarios u
        ORDER BY u.id DESC";

$resultado = $conn->query($sql);
if (!$resultado) {
    responder(["ok" => false, "mensaje" => "Error en la base de datos. ¿Importaste las tablas?"], 500);
}

responder($resultado->fetch_all(MYSQLI_ASSOC));
?>