package com.example.conectamente.viewmodel


import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.example.conectamente.data.repository.AppRepository

class ConfiguracionViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository.get(app)

    val nombre: String = repo.nombreActual()
    val email: String = repo.emailActual()

    var textoGrande by mutableStateOf(repo.textoGrande.value)
        private set
    var confirmarLlamada by mutableStateOf(repo.confirmarLlamada())
        private set
    var mostrarDialogoBorrar by mutableStateOf(false)
        private set

    fun onTextoGrande(valor: Boolean) {
        textoGrande = valor
        repo.cambiarTextoGrande(valor)
    }

    fun onConfirmarLlamada(valor: Boolean) {
        confirmarLlamada = valor
        repo.cambiarConfirmarLlamada(valor)
    }

    fun pedirBorrar() { mostrarDialogoBorrar = true }
    fun cancelarBorrar() { mostrarDialogoBorrar = false }

    fun confirmarBorrar(onListo: () -> Unit) {
        repo.borrarHistorial()
        mostrarDialogoBorrar = false
        onListo()
    }
}