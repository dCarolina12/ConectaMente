package com.example.conectamente.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.conectamente.ui.components.*
import com.example.conectamente.ui.theme.*
import com.example.conectamente.ui.navegation.Rutas
import com.example.conectamente.viewmodel.LoginViewModel

@Composable
fun PantallaLogin(navController: NavController, vm: LoginViewModel = viewModel()) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(AzulClaro, Color.White)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)
        ) {
            Text("Iniciar sesión", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = TextoOscuro)
            AvatarCabecera()
            Spacer(Modifier.height(6.dp))

            CampoTexto(vm.email, vm::onEmailChange, "Email", Icons.Default.Email)
            CampoTexto(
                vm.password, vm::onPasswordChange, "Contraseña", Icons.Default.Lock,
                esPassword = true, mostrarPassword = vm.verPassword
            )

            FilaCheck("Recordar mi email", vm.recordarEmail, vm::onRecordarChange)
            FilaCheck("Ver contraseña", vm.verPassword, vm::onVerPasswordChange)

            vm.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, fontSize = 14.sp)
            }

            BotonPrincipal("Iniciar sesión") {
                vm.iniciarSesion(
                    onAdmin = { navController.navigate(Rutas.ADMIN) },
                    onUsuario = {
                        navController.navigate(Rutas.HOME) {
                            popUpTo(Rutas.LOGIN) { inclusive = true }
                        }
                    }
                )
            }

            TextButton(onClick = { navController.navigate(Rutas.REGISTRO) }) {
                Text("¿No tienes cuenta? Regístrate", color = Azul, fontWeight = FontWeight.SemiBold)
            }

            MensajeProteccion()
        }
    }
}