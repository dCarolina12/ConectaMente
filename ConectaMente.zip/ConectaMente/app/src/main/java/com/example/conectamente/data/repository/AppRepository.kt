package com.example.conectamente.data.repository

import android.content.Context
import com.example.conectamente.data.local.BaseDatosHelper
import com.example.conectamente.data.local.SesionManager
import com.example.conectamente.data.model.Partida
import com.example.conectamente.data.model.Usuario
import com.example.conectamente.data.model.Contacto
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import com.example.conectamente.data.model.AnimoGuardado

class AppRepository private constructor(context: Context) {

    private val db = BaseDatosHelper(context)
    private val sesion = SesionManager(context)
    private val _textoGrande = MutableStateFlow(sesion.textoGrande())
    val textoGrande: StateFlow<Boolean> = _textoGrande.asStateFlow()

    fun haySesion() = sesion.haySesion()
    fun nombreActual() = sesion.nombreActual()
    fun cerrarSesion() = sesion.cerrarSesion()
    fun emailRecordado() = sesion.emailRecordado()
    fun recordarEmail(email: String) = sesion.recordarEmail(email)
    fun olvidarEmail() = sesion.olvidarEmail()

    fun esAdmin(email: String, password: String): Boolean =
        email.trim() == ADMIN_USUARIO && password == ADMIN_PASSWORD

    fun iniciarSesion(email: String, password: String): Boolean {
        if (!db.validarLogin(email, password)) return false
        sesion.guardarSesion(email, db.obtenerNombre(email))
        return true
    }

    fun registrarUsuario(email: String, usuario: String, password: String) =
        db.registrarUsuario(email, usuario, password)

    fun obtenerUsuarios(): List<Usuario> = db.obtenerUsuarios()

    fun actualizarUsuario(id: Int, email: String, usuario: String) =
        db.actualizarUsuario(id, email, usuario)

    fun eliminarUsuario(id: Int) = db.eliminarUsuario(id)


    fun guardarPartida(intentos: Int, segundos: Int) =
        db.guardarPartida(sesion.emailActual(), intentos, segundos)

    fun obtenerPartidas(): List<Partida> = db.obtenerPartidas(sesion.emailActual())


    fun guardarAnimo(estado: String) = db.guardarAnimo(sesion.emailActual(), estado)

    fun obtenerAnimos(): List<AnimoGuardado> = db.obtenerAnimos(sesion.emailActual())

    fun emailActual() = sesion.emailActual()

    fun cambiarTextoGrande(valor: Boolean) {
        sesion.guardarTextoGrande(valor)
        _textoGrande.value = valor
    }

    fun confirmarLlamada() = sesion.confirmarLlamada()
    fun cambiarConfirmarLlamada(valor: Boolean) = sesion.guardarConfirmarLlamada(valor)
    fun borrarHistorial() = db.borrarHistorial(sesion.emailActual())

    fun agregarContacto(nombre: String, telefono: String) =
        db.agregarContacto(sesion.emailActual(), nombre, telefono)

    fun obtenerContactos(): List<Contacto> = db.obtenerContactos(sesion.emailActual())

    fun actualizarContacto(id: Int, nombre: String, telefono: String) =
        db.actualizarContacto(id, nombre, telefono)

    fun eliminarContacto(id: Int) = db.eliminarContacto(id)

    companion object {

        private const val ADMIN_USUARIO = "admin"
        private const val ADMIN_PASSWORD = "admin123"

        @Volatile
        private var INSTANCE: AppRepository? = null

        fun get(context: Context): AppRepository =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: AppRepository(context.applicationContext).also { INSTANCE = it }
            }


    }
}