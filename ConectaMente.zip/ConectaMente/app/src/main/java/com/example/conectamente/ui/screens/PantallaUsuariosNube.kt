package com.example.conectamente.ui.screens


import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.conectamente.data.model.PerfilRemoto
import com.example.conectamente.data.model.UsuarioRemoto
import com.example.conectamente.ui.components.*
import com.example.conectamente.ui.theme.*
import com.example.conectamente.viewmodel.UiState
import com.example.conectamente.viewmodel.UsuariosNubeViewModel

@Composable
fun PantallaUsuariosNube(navController: NavController, vm: UsuariosNubeViewModel = viewModel()) {

    val lista = vm.usuarios
    val consulta = vm.consulta

    Scaffold(
        containerColor = AzulClaro,
        topBar = {
            BarraSuperior(
                titulo = "Usuarios en el servidor",
                onAtras = { navController.popBackStack() }
            ) {
                IconButton(onClick = vm::cargar) {
                    Icon(Icons.Default.Refresh, contentDescription = "Actualizar")
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {

            // Consulta individual (GET con parámetro)
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CampoTexto(
                    vm.emailBuscado, vm::onEmailChange, "Consultar por email",
                    Icons.Default.Search, teclado = KeyboardType.Email
                )
                BotonPrincipal("Consultar usuario") { vm.consultar() }

                when (consulta) {
                    is UiState.Idle -> {}
                    is UiState.Loading -> LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Azul)
                    is UiState.Error -> Text("❌ ${consulta.message}", color = Color(0xFFD64545), fontSize = 14.sp)
                    is UiState.Success -> TarjetaPerfil(consulta.data)
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                when (lista) {
                    is UiState.Idle, is UiState.Loading ->
                        PantallaCargando("Consultando usuarios...")

                    is UiState.Error ->
                        PantallaError(lista.message, vm::cargar)

                    is UiState.Success ->
                        if (lista.data.isEmpty()) {
                            Column(
                                modifier = Modifier.fillMaxSize().padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text("☁️", fontSize = 52.sp)
                                Text(
                                    "El servidor aún no tiene usuarios.\nPide que sincronicen desde la app.",
                                    color = GrisTexto,
                                    textAlign = TextAlign.Center
                                )
                            }
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(lista.data, key = { it.id }) { u ->
                                    TarjetaUsuarioNube(u) { vm.consultar(u.email) }
                                }
                            }
                        }
                }
            }
        }
    }
}

@Composable
private fun TarjetaUsuarioNube(u: UsuarioRemoto, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth().clickable { onClick() }
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(46.dp).background(Azul, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    u.usuario.firstOrNull()?.uppercase() ?: "?",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(u.usuario, fontWeight = FontWeight.Bold, color = TextoOscuro)
                Text(u.email, color = GrisTexto, fontSize = 13.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("🎮 ${u.partidas}", color = TextoOscuro, fontSize = 13.sp)
                Text("😊 ${u.animos}", color = TextoOscuro, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun TarjetaPerfil(p: PerfilRemoto) {
    Surface(shape = RoundedCornerShape(16.dp), color = Color.White, shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(p.usuario, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextoOscuro)
            Text(p.email, color = GrisTexto, fontSize = 13.sp)
            Spacer(Modifier.height(4.dp))
            Text("🎮 Partidas: ${p.totalPartidas}", color = TextoOscuro)
            Text("⏱️ Mejor tiempo: ${p.mejorTiempo?.let { formatoTiempo(it) } ?: "—"}", color = TextoOscuro)
            Text("🎯 Menos intentos: ${p.menosIntentos?.toString() ?: "—"}", color = TextoOscuro)
            Text("😊 Ánimos registrados: ${p.totalAnimos}", color = TextoOscuro)
        }
    }
}