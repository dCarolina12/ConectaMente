package com.example.conectamente.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.conectamente.data.model.Contacto
import com.example.conectamente.ui.components.*
import com.example.conectamente.ui.theme.*
import com.example.conectamente.viewmodel.ContactosViewModel
import com.example.conectamente.ui.components.AlertDialog

@Composable
fun PantallaContactos(
    navController: NavController,
    esVideo: Boolean,
    vm: ContactosViewModel = viewModel()
) {
    val context = LocalContext.current

    fun ejecutar(c: Contacto) {
        if (esVideo) videollamada(context, c.telefono) else llamar(context, c.telefono)
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            BarraSuperior(
                titulo = if (esVideo) "Videollamada" else "Llamar a un familiar",
                onAtras = { navController.popBackStack() }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = vm::abrirAgregar,
                containerColor = Amarillo,
                contentColor = TextoOscuro,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Agregar contacto", fontWeight = FontWeight.Bold) }
            )
        },
        modifier = Modifier.background(Brush.verticalGradient(listOf(VerdeClaro, Color.White)))
    ) { padding ->
        if (vm.contactos.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding).padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("👨‍👩‍👧", fontSize = 56.sp)
                    Text("Aún no tienes contactos", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextoOscuro)
                    Text(
                        "Toca «Agregar contacto» para guardar a tu familia",
                        color = GrisTexto,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(vm.contactos, key = { it.id }) { c ->
                    TarjetaContacto(
                        contacto = c,
                        esVideo = esVideo,
                        onAccion = { if (vm.confirmarAntes) vm.pedirConfirmacion(c) else ejecutar(c) },
                        onEditar = { vm.abrirEditar(c) },
                        onEliminar = { vm.pedirEliminar(c) }
                    )
                }
            }
        }
    }

    if (vm.mostrarFormulario) {
        AlertDialog(
            onDismissRequest = vm::cerrarFormulario,
            title = { Text(if (vm.contactoEditando == null) "Nuevo contacto" else "Editar contacto") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    CampoTexto(vm.nombre, vm::onNombreChange, "Nombre", Icons.Default.Person)
                    CampoTexto(
                        vm.telefono, vm::onTelefonoChange, "Teléfono", Icons.Default.Phone,
                        teclado = KeyboardType.Phone
                    )
                    vm.errorForm?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = { TextButton(onClick = vm::guardar) { Text("Guardar") } },
            dismissButton = { TextButton(onClick = vm::cerrarFormulario) { Text("Cancelar") } }
        )
    }

    vm.contactoEliminar?.let { c ->
        AlertDialog(
            onDismissRequest = vm::cancelarEliminar,
            title = { Text("Eliminar contacto") },
            text = { Text("¿Seguro que quieres eliminar a ${c.nombre}?") },
            confirmButton = {
                TextButton(onClick = vm::confirmarEliminar) {
                    Text("Eliminar", color = Color(0xFFD64545))
                }
            },
            dismissButton = { TextButton(onClick = vm::cancelarEliminar) { Text("Cancelar") } }
        )
    }

    vm.contactoPendiente?.let { c ->
        AlertDialog(
            onDismissRequest = vm::cancelarConfirmacion,
            title = { Text(if (esVideo) "Videollamada" else "Llamar") },
            text = {
                Text(
                    if (esVideo) "¿Quieres hacer una videollamada con ${c.nombre}?"
                    else "¿Quieres llamar a ${c.nombre}?"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.cancelarConfirmacion()
                    ejecutar(c)
                }) { Text("Sí") }
            },
            dismissButton = { TextButton(onClick = vm::cancelarConfirmacion) { Text("No") } }
        )
    }
}

@Composable
private fun TarjetaContacto(
    contacto: Contacto,
    esVideo: Boolean,
    onAccion: () -> Unit,
    onEditar: () -> Unit,
    onEliminar: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(48.dp).background(Azul, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        contacto.nombre.firstOrNull()?.uppercase() ?: "?",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(contacto.nombre, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextoOscuro)
                    Text(contacto.telefono, color = GrisTexto, fontSize = 14.sp)
                }
                IconButton(onClick = onEditar) {
                    Icon(Icons.Default.Edit, contentDescription = "Editar", tint = Azul)
                }
                IconButton(onClick = onEliminar) {
                    Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = Color(0xFFD64545))
                }
            }

            Spacer(Modifier.height(12.dp))

            Button(
                onClick = onAccion,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Verde, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(
                    if (esVideo) "📹  Videollamada" else "📞  Llamar",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}