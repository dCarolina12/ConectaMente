package com.example.conectamente.ui.screens

import kotlin.text.get

import androidx.compose.foundation.background
import com.example.conectamente.ui.navegation.Rutas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.conectamente.data.model.LISTA_ANIMOS
import com.example.conectamente.data.model.Partida
import com.example.conectamente.data.model.TipoAnimo
import com.example.conectamente.ui.components.*
import com.example.conectamente.ui.theme.*
import com.example.conectamente.viewmodel.ResultadosViewModel

@Composable
fun PantallaResultados(navController: NavController, vm: ResultadosViewModel = viewModel()) {

    Scaffold(
        containerColor = Color.Transparent,
        topBar = { BarraSuperior("Consultar resultados", onAtras = { navController.popBackStack() }) },
        modifier = Modifier.background(Brush.verticalGradient(listOf(AzulClaro, Color.White)))
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TarjetaDato("🎮", "${vm.partidas.size}", "Partidas", Modifier.weight(1f))
                TarjetaDato("⏱️", vm.mejorTiempo?.let { formatoTiempo(it) } ?: "—", "Mejor tiempo", Modifier.weight(1f))
                TarjetaDato("🎯", vm.menosIntentos?.toString() ?: "—", "Menos intentos", Modifier.weight(1f))
            }

            SeccionTitulo("Mis últimas partidas")
            if (vm.partidas.isEmpty()) {
                TextoVacio("Aún no has jugado. ¡Anímate con los juegos de memoria!")
            } else {
                vm.partidas.take(5).forEach { FilaPartida(it) }
            }

            SeccionTitulo("Mi estado de ánimo")
            if (vm.totalAnimos == 0) {
                TextoVacio("Aún no has registrado tu ánimo.")
            } else {
                LISTA_ANIMOS.forEach { animo ->
                    BarraAnimo(animo, vm.animos[animo.clave] ?: 0, vm.totalAnimos)
                }
            }

            Spacer(Modifier.height(4.dp))
            FraseCard("La edad es solo un número; la curiosidad y la pasión por descubrir nuevos mundos no tienen límite.")

            BotonPrincipal("Siguiente") {
                navController.navigate(Rutas.ANIMO) {
                    popUpTo(Rutas.RESULTADOS) { inclusive = true }
                }
            }
        }
    }
}

@Composable
private fun TarjetaDato(emoji: String, valor: String, etiqueta: String, modifier: Modifier = Modifier) {
    Surface(shape = RoundedCornerShape(18.dp), color = Color.White, shadowElevation = 2.dp, modifier = modifier) {
        Column(
            modifier = Modifier.padding(vertical = 14.dp, horizontal = 6.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(emoji, fontSize = 24.sp)
            Text(valor, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Azul)
            Text(etiqueta, fontSize = 11.sp, color = GrisTexto, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun SeccionTitulo(texto: String) {
    Text(texto, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextoOscuro)
}

@Composable
private fun TextoVacio(texto: String) {
    Surface(shape = RoundedCornerShape(14.dp), color = Color.White.copy(alpha = 0.7f)) {
        Text(texto, color = GrisTexto, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().padding(16.dp))
    }
}

@Composable
private fun FilaPartida(p: Partida) {
    Surface(shape = RoundedCornerShape(14.dp), color = Color.White, shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🧠", fontSize = 24.sp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(p.fecha, color = GrisTexto, fontSize = 12.sp)
                Text(
                    "${p.intentos} intentos · ${formatoTiempo(p.segundos)}",
                    color = TextoOscuro,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun BarraAnimo(animo: TipoAnimo, cantidad: Int, total: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(animo.emoji, fontSize = 22.sp)
        Spacer(Modifier.width(8.dp))
        Text(animo.etiqueta, color = TextoOscuro, fontSize = 13.sp, modifier = Modifier.width(76.dp))
        Box(
            modifier = Modifier.weight(1f).height(12.dp).clip(RoundedCornerShape(6.dp)).background(Color.White)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(cantidad.toFloat() / total)
                    .fillMaxHeight()
                    .background(Azul)
            )
        }
        Spacer(Modifier.width(10.dp))
        Text("$cantidad", fontWeight = FontWeight.Bold, color = TextoOscuro)
    }
}