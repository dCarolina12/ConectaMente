package com.example.conectamente.ui.screens


import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.conectamente.ui.components.TarjetaMenu
import com.example.conectamente.ui.navegation.Rutas
import com.example.conectamente.ui.theme.*
import com.example.conectamente.viewmodel.HomeViewModel
import com.example.conectamente.ui.components.AlertDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaHome(navController: NavController, vm: HomeViewModel = viewModel()) {

    BackHandler { vm.pedirCerrarSesion() }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text("Home", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = vm::pedirCerrarSesion) {
                        Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Cerrar sesión")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Azul,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        modifier = Modifier.background(Brush.verticalGradient(listOf(AzulClaro, Color.White)))
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                if (vm.nombre.isBlank()) "¡Hola! 👋" else "¡Hola, ${vm.nombre}! 👋",
                fontSize = 26.sp, fontWeight = FontWeight.Bold, color = TextoOscuro
            )
            Text("¿Qué quieres hacer hoy?", fontSize = 16.sp, color = GrisTexto)
            Spacer(Modifier.height(4.dp))

            TarjetaMenu("🧠", "Juegos de memoria", "Mantén la mente ágil jugando", AzulClaro) {
                navController.navigate(Rutas.MEMORIA)
            }
            TarjetaMenu("📊", "Ver mis resultados", "Consulta cómo te ha ido en los juegos", AzulClaro) {
                navController.navigate(Rutas.RESULTADOS)
            }
            TarjetaMenu("😊", "Registrar mi ánimo", "Cuéntanos cómo te sientes hoy", RosaAnimo) {
                navController.navigate(Rutas.ANIMO)
            }
            TarjetaMenu("📞", "Contactar familiares", "Llama o haz videollamada a tu familia", VerdeClaro) {
                navController.navigate(Rutas.CONTACTAR)
            }
            TarjetaMenu("⚙️", "Configuración", "Letra grande, llamadas y más", AmarilloClaro) {
                navController.navigate(Rutas.CONFIGURACION)
            }
            TarjetaMenu("☁️", "Mi historial en línea", "Respalda y consulta tus datos en el servidor", AzulClaro) {
                navController.navigate(Rutas.NUBE)
            }
        }
    }

    if (vm.mostrarDialogoSalir) {
        AlertDialog(
            onDismissRequest = vm::cancelarCerrarSesion,
            title = { Text("Cerrar sesión") },
            text = { Text("¿Quieres cerrar sesión?") },
            confirmButton = {
                TextButton(onClick = {
                    vm.confirmarCerrarSesion {
                        navController.navigate(Rutas.LOGIN) {
                            popUpTo(Rutas.HOME) { inclusive = true }
                        }
                    }
                }) { Text("Sí") }
            },
            dismissButton = { TextButton(onClick = vm::cancelarCerrarSesion) { Text("No") } }
        )
    }
}