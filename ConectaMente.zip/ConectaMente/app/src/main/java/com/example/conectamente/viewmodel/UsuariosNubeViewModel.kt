package com.example.conectamente.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.conectamente.data.model.PerfilRemoto
import com.example.conectamente.data.model.UsuarioRemoto
import com.example.conectamente.data.repository.ApiException
import com.example.conectamente.data.repository.NubeRepository
import com.example.conectamente.utils.NetworkUtils
import kotlinx.coroutines.launch

class UsuariosNubeViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = NubeRepository(app)

    var usuarios by mutableStateOf<UiState<List<UsuarioRemoto>>>(UiState.Idle)
        private set

    var consulta by mutableStateOf<UiState<PerfilRemoto>>(UiState.Idle)
        private set

    var emailBuscado by mutableStateOf("")
        private set

    init { cargar() }

    fun onEmailChange(valor: String) { emailBuscado = valor }

    private fun hayRed() = NetworkUtils.hayConexion(getApplication())

    fun cargar() {
        if (!hayRed()) {
            usuarios = UiState.Error("Sin conexión. Activa el WiFi o los datos e inténtalo de nuevo.")
            return
        }
        viewModelScope.launch {
            usuarios = UiState.Loading
            try {
                usuarios = UiState.Success(repo.listarUsuarios())
            } catch (e: ApiException) {
                usuarios = UiState.Error(e.message ?: "Ocurrió un error")
            }
        }
    }

    fun consultar(email: String = emailBuscado) {
        if (email.isBlank()) {
            consulta = UiState.Error("Escribe el email que quieres consultar")
            return
        }
        emailBuscado = email
        if (!hayRed()) {
            consulta = UiState.Error("Sin conexión. Activa el WiFi o los datos e inténtalo de nuevo.")
            return
        }
        viewModelScope.launch {
            consulta = UiState.Loading
            try {
                consulta = UiState.Success(repo.consultarUsuario(email))
            } catch (e: ApiException) {
                consulta = UiState.Error(e.message ?: "Ocurrió un error")
            }
        }
    }
}