package com.example.conectamente.viewmodel


import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.example.conectamente.data.model.TipoAnimo
import com.example.conectamente.data.repository.AppRepository

class AnimoViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository.get(app)

    var seleccion by mutableStateOf<TipoAnimo?>(null)
        private set

    fun seleccionar(animo: TipoAnimo) { seleccion = animo }

    fun guardar(): Boolean {
        val animo = seleccion ?: return false
        repo.guardarAnimo(animo.clave)
        return true
    }
}