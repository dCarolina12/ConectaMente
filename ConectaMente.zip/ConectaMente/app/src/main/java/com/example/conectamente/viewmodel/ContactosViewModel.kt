package com.example.conectamente.viewmodel


import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.example.conectamente.data.model.Contacto
import com.example.conectamente.data.repository.AppRepository

class ContactosViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository.get(app)

    var contactos by mutableStateOf<List<Contacto>>(emptyList())
        private set

    var mostrarFormulario by mutableStateOf(false)
        private set
    var contactoEditando by mutableStateOf<Contacto?>(null)
        private set
    var nombre by mutableStateOf("")
        private set
    var telefono by mutableStateOf("")
        private set
    var errorForm by mutableStateOf<String?>(null)
        private set


    var contactoEliminar by mutableStateOf<Contacto?>(null)
        private set
    var contactoPendiente by mutableStateOf<Contacto?>(null)
        private set

    val confirmarAntes: Boolean = repo.confirmarLlamada()

    init { cargar() }


    fun cargar() { contactos = repo.obtenerContactos() }


    fun abrirAgregar() {
        contactoEditando = null
        nombre = ""
        telefono = ""
        errorForm = null
        mostrarFormulario = true
    }

    fun abrirEditar(c: Contacto) {
        contactoEditando = c
        nombre = c.nombre
        telefono = c.telefono
        errorForm = null
        mostrarFormulario = true
    }

    fun cerrarFormulario() { mostrarFormulario = false }
    fun onNombreChange(v: String) { nombre = v; errorForm = null }
    fun onTelefonoChange(v: String) { telefono = v; errorForm = null }

    fun guardar() {
        val digitos = telefono.filter { it.isDigit() }
        when {
            nombre.isBlank() -> errorForm = "Escribe el nombre"
            digitos.length < 7 -> errorForm = "El teléfono debe tener al menos 7 dígitos"
            else -> {
                val editando = contactoEditando
                val ok = if (editando == null)
                    repo.agregarContacto(nombre, telefono)
                else
                    repo.actualizarContacto(editando.id, nombre, telefono)

                if (ok) {
                    cargar()
                    mostrarFormulario = false
                } else {
                    errorForm = "No se pudo guardar"
                }
            }
        }
    }


    fun pedirEliminar(c: Contacto) { contactoEliminar = c }
    fun cancelarEliminar() { contactoEliminar = null }

    fun confirmarEliminar() {
        contactoEliminar?.let {
            repo.eliminarContacto(it.id)
            cargar()
        }
        contactoEliminar = null
    }


    fun pedirConfirmacion(c: Contacto) { contactoPendiente = c }
    fun cancelarConfirmacion() { contactoPendiente = null }
}