package com.example.conectamente.data.model

data class Partida(
    val id: Int,
    val intentos: Int,
    val segundos: Int,
    val fecha: String
)