package com.example.conectamente.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.conectamente.ui.components.*
import com.example.conectamente.ui.theme.*
import com.example.conectamente.viewmodel.RegistroViewModel

@Composable
fun PantallaRegistro(navController: NavController, vm: RegistroViewModel = viewModel()) {
    val context = LocalContext.current

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            BarraSuperior(
                titulo = "Registrarse",
                onAtras = { navController.popBackStack() },
                containerColor = Color.Transparent,
                contentColor = TextoOscuro
            )
        },
        modifier = Modifier.background(Brush.verticalGradient(listOf(AzulClaro, Color.White)))
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            AvatarCabecera()
            Spacer(Modifier.height(6.dp))

            CampoTexto(vm.email, vm::onEmailChange, "Email", Icons.Default.Email)
            CampoTexto(vm.usuario, vm::onUsuarioChange, "Usuario", Icons.Default.Person)
            CampoTexto(
                vm.password, vm::onPasswordChange, "Contraseña", Icons.Default.Lock,
                esPassword = true, mostrarPassword = vm.verPassword
            )
            FilaCheck("Ver contraseña", vm.verPassword, vm::onVerPasswordChange)

            vm.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, fontSize = 14.sp)
            }

            BotonPrincipal("Registrarse") {
                vm.registrar(onExito = {
                    Toast.makeText(context, "Registro exitoso", Toast.LENGTH_SHORT).show()
                    navController.popBackStack()
                })
            }

            TextButton(onClick = { navController.popBackStack() }) {
                Text("¿Ya tienes cuenta? Inicia sesión", color = Azul, fontWeight = FontWeight.SemiBold)
            }

            MensajeProteccion()
        }
    }
}