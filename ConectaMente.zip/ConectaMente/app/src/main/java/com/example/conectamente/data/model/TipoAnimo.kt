package com.example.conectamente.data.model

data class TipoAnimo(val clave: String, val emoji: String, val etiqueta: String)

val LISTA_ANIMOS = listOf(
    TipoAnimo("feliz", "😊", "Feliz"),
    TipoAnimo("tranquilo", "😌", "Tranquilo"),
    TipoAnimo("neutral", "😐", "Neutral"),
    TipoAnimo("cansado", "😴", "Cansado"),
    TipoAnimo("triste", "😢", "Triste"),
    TipoAnimo("enojado", "😠", "Enojado")
)