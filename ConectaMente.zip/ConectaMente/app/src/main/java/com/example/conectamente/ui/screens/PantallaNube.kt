package com.example.conectamente.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.conectamente.data.model.*
import com.example.conectamente.ui.components.*
import com.example.conectamente.ui.theme.*
import com.example.conectamente.viewmodel.NubeViewModel
import com.example.conectamente.viewmodel.UiState

@Composable
fun PantallaNube(navController: NavController, vm: NubeViewModel = viewModel()) {

    val estado = vm.historial

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            BarraSuperior(
                titulo = "Mi historial en línea",
                onAtras = { navController.popBackStack() }
            ) {
                IconButton(onClick = vm::cargarHistorial) {
                    Icon(Icons.Default.Refresh, contentDescription = "Actualizar")
                }
            }
        },
        modifier = Modifier.background(Brush.verticalGradient(listOf(AzulClaro, Color.White)))
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { TarjetaServidor(vm.direccion, vm::onDireccionChange, vm::guardarDireccion) }
            item { TarjetaSincronizar(vm.sincronizacion, vm::sincronizar) }

            when (estado) {
                is UiState.Idle, is UiState.Loading -> item {
                    Box(modifier = Modifier.fillMaxWidth().height(180.dp)) {
                        PantallaCargando("Consultando el servidor...")
                    }
                }

                is UiState.Error -> item {
                    Box(modifier = Modifier.fillMaxWidth().height(300.dp)) {
                        PantallaError(estado.message, vm::cargarHistorial)
                    }
                }

                is UiState.Success -> contenidoHistorial(estado.data)
            }
        }
    }
}

private fun LazyListScope.contenidoHistorial(h: HistorialRemoto) {
    val perfil = h.perfil

    if (perfil == null) {
        item {
            MensajeVacio(
                "☁️",
                "Aún no hay datos tuyos en el servidor",
                "Toca «Sincronizar ahora» para respaldar tus partidas y tu estado de ánimo."
            )
        }
        return
    }

    item { ResumenPerfil(perfil) }

    item { Titulo("Mis partidas en el servidor") }
    if (h.partidas.isEmpty()) {
        item { MensajeVacio("🧠", "Sin partidas", "Juega al juego de memoria y vuelve a sincronizar.") }
    } else {
        items(h.partidas, key = { "p${it.id}" }) { FilaPartida(it) }
    }

    item { Titulo("Mi estado de ánimo en el servidor") }
    if (h.animos.isEmpty()) {
        item { MensajeVacio("😊", "Sin registros", "Registra tu ánimo y vuelve a sincronizar.") }
    } else {
        items(h.animos, key = { "a${it.id}" }) { FilaAnimo(it) }
    }
}

@Composable
private fun TarjetaServidor(direccion: String, onCambio: (String) -> Unit, onGuardar: () -> Unit) {
    Surface(shape = RoundedCornerShape(20.dp), color = Color.White, shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("🖥️ Servidor PHP", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = TextoOscuro)
            CampoTexto(direccion, onCambio, "Dirección del servidor", Icons.Default.Cloud)
            Text(
                "Emulador: 10.0.2.2   ·   Celular real: la IP de tu computador (ej. 192.168.1.10)",
                color = GrisTexto,
                fontSize = 12.sp
            )
            BotonPrincipal("Guardar y consultar", onGuardar)
        }
    }
}

@Composable
private fun TarjetaSincronizar(estado: UiState<SincronizarResponse>, onSincronizar: () -> Unit) {
    Surface(shape = RoundedCornerShape(20.dp), color = Color.White, shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("☁️ Respaldar mis datos", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = TextoOscuro)
            Text(
                "Sube tus partidas y tu estado de ánimo al servidor para no perderlos.",
                color = GrisTexto,
                fontSize = 14.sp
            )
            BotonPrincipal("Sincronizar ahora", onSincronizar)

            when (estado) {
                is UiState.Loading -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Azul)
                    Spacer(Modifier.width(10.dp))
                    Text("Sincronizando...", color = GrisTexto)
                }

                is UiState.Success -> Text(
                    "✅ ${estado.data.mensaje}: ${estado.data.partidasNuevas} partidas y ${estado.data.animosNuevos} ánimos nuevos",
                    color = Color(0xFF2E7D32),
                    fontSize = 14.sp
                )

                is UiState.Error -> Text("❌ ${estado.message}", color = Color(0xFFD64545), fontSize = 14.sp)

                is UiState.Idle -> {}
            }
        }
    }
}

@Composable
private fun ResumenPerfil(p: PerfilRemoto) {
    val ultimo = LISTA_ANIMOS.firstOrNull { it.clave == p.ultimoAnimo }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("¡Hola, ${p.usuario}! 👋", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextoOscuro)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TarjetaDato("🎮", "${p.totalPartidas}", "Partidas", Modifier.weight(1f))
            TarjetaDato("⏱️", p.mejorTiempo?.let { formatoTiempo(it) } ?: "—", "Mejor tiempo", Modifier.weight(1f))
            TarjetaDato("😊", "${p.totalAnimos}", "Ánimos", Modifier.weight(1f))
        }

        if (ultimo != null) {
            Text("Último ánimo registrado: ${ultimo.emoji} ${ultimo.etiqueta}", color = GrisTexto, fontSize = 14.sp)
        }
    }
}

@Composable
private fun TarjetaDato(emoji: String, valor: String, etiqueta: String, modifier: Modifier = Modifier) {
    Surface(shape = RoundedCornerShape(18.dp), color = Color.White, shadowElevation = 2.dp, modifier = modifier) {
        Column(
            modifier = Modifier.padding(vertical = 14.dp, horizontal = 6.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(emoji, fontSize = 24.sp)
            Text(valor, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Azul)
            Text(etiqueta, fontSize = 11.sp, color = GrisTexto, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun Titulo(texto: String) {
    Text(texto, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextoOscuro, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun MensajeVacio(emoji: String, titulo: String, detalle: String) {
    Surface(shape = RoundedCornerShape(16.dp), color = Color.White.copy(alpha = 0.8f), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 36.sp)
            Spacer(Modifier.height(6.dp))
            Text(titulo, fontWeight = FontWeight.Bold, color = TextoOscuro, textAlign = TextAlign.Center)
            Text(detalle, color = GrisTexto, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun FilaPartida(p: PartidaRemota) {
    Surface(shape = RoundedCornerShape(14.dp), color = Color.White, shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🧠", fontSize = 24.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(p.fecha, color = GrisTexto, fontSize = 12.sp)
                Text("${p.intentos} intentos · ${formatoTiempo(p.segundos)}", color = TextoOscuro, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun FilaAnimo(a: AnimoRemoto) {
    val animo = LISTA_ANIMOS.firstOrNull { it.clave == a.estado }
    Surface(shape = RoundedCornerShape(14.dp), color = Color.White, shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(animo?.emoji ?: "🙂", fontSize = 26.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(a.fecha, color = GrisTexto, fontSize = 12.sp)
                Text(animo?.etiqueta ?: a.estado, color = TextoOscuro, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}