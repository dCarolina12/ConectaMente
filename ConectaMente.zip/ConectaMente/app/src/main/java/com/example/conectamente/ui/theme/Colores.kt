package com.example.conectamente.ui.theme
import androidx.compose.ui.graphics.Color

val Azul = Color(0xFF3B6FD4)
val AzulClaro = Color(0xFFDCE9FB)
val Amarillo = Color(0xFFF6D68B)
val TextoOscuro = Color(0xFF1F2A44)
val GrisTexto = Color(0xFF6B7280)
val VerdeClaro = Color(0xFFD6F2E0)
val RosaAnimo = Color(0xFFFF9A9A)
val RosaClaro = Color(0xFFFFD9D9)
val Verde = Color(0xFF4CAF7A)
val AmarilloClaro = Color(0xFFFFF1CC)