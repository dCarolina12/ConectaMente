package com.example.conectamente.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.example.conectamente.data.repository.AppRepository

class LoginViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository.get(app)

    var email by mutableStateOf(repo.emailRecordado())
        private set
    var password by mutableStateOf("")
        private set
    var verPassword by mutableStateOf(false)
        private set
    var recordarEmail by mutableStateOf(repo.emailRecordado().isNotEmpty())
        private set
    var error by mutableStateOf<String?>(null)
        private set

    fun onEmailChange(valor: String) { email = valor; error = null }
    fun onPasswordChange(valor: String) { password = valor; error = null }
    fun onVerPasswordChange(valor: Boolean) { verPassword = valor }
    fun onRecordarChange(valor: Boolean) { recordarEmail = valor }

    fun iniciarSesion(onAdmin: () -> Unit, onUsuario: () -> Unit) {
        when {
            email.isBlank() || password.isBlank() ->
                error = "Completa todos los campos"

            repo.esAdmin(email, password) ->
                onAdmin()

            repo.iniciarSesion(email, password) -> {
                if (recordarEmail) repo.recordarEmail(email) else repo.olvidarEmail()
                onUsuario()
            }

            else -> error = "Email o contraseña incorrectos"
        }
    }
}