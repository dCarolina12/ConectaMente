package com.example.conectamente.data.model


data class Contacto(
    val id: Int,
    val nombre: String,
    val telefono: String
)