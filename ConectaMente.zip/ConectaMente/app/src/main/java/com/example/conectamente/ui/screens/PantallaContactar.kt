package com.example.conectamente.ui.screens


import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.conectamente.ui.components.*
import com.example.conectamente.ui.navegation.Rutas
import com.example.conectamente.ui.theme.*

@Composable
fun PantallaContactar(navController: NavController) {
    Scaffold(
        containerColor = Color.Transparent,
        topBar = { BarraSuperior("Contactar familiares", onAtras = { navController.popBackStack() }) },
        modifier = Modifier.background(Brush.verticalGradient(listOf(VerdeClaro, Color.White)))
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            TarjetaMenu(
                emoji = "📞",
                titulo = "Llamar a un familiar",
                descripcion = "Elige a quién quieres llamar",
                color = VerdeClaro
            ) { navController.navigate(Rutas.LLAMAR) }

            TarjetaMenu(
                emoji = "📹",
                titulo = "Videollamada con un familiar",
                descripcion = "Habla viéndose las caras",
                color = AzulClaro
            ) { navController.navigate(Rutas.VIDEOLLAMADA) }

            Spacer(Modifier.height(4.dp))
            FraseCard("Estar cerca de quienes quieres también hace bien al corazón.")
        }
    }
}