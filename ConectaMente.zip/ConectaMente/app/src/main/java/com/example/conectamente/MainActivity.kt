package com.example.conectamente

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import com.example.conectamente.ui.navegation.AppNavigation
import com.example.conectamente.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val mainViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val textoGrande by mainViewModel.textoGrande.collectAsState()
            val densidad = LocalDensity.current

            CompositionLocalProvider(
                LocalDensity provides Density(
                    density = densidad.density,
                    fontScale = if (textoGrande) densidad.fontScale * 1.3f else densidad.fontScale
                )
            ) {
                MaterialTheme {
                    AppNavigation(haySesion = mainViewModel.haySesion)
                }
            }
        }
    }
}