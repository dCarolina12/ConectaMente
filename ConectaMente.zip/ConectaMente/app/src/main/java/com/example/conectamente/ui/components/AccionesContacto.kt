package com.example.conectamente.ui.components

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

private const val CODIGO_PAIS = "57"

fun llamar(context: Context, telefono: String) {
    val numero = telefono.filter { it.isDigit() || it == '+' }
    abrir(context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$numero")))
}

fun videollamada(context: Context, telefono: String) {
    var digitos = telefono.filter { it.isDigit() }
    if (digitos.length == 10) digitos = CODIGO_PAIS + digitos
    abrir(context, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digitos")))
}

private fun abrir(context: Context, intent: Intent) {
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "No se pudo abrir la aplicación", Toast.LENGTH_SHORT).show()
    }
}