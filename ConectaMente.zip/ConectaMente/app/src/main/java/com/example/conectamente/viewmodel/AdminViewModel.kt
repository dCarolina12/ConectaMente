package com.example.conectamente.viewmodel


import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.example.conectamente.data.model.Usuario
import com.example.conectamente.data.repository.AppRepository

class AdminViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository.get(app)

    var usuarios by mutableStateOf<List<Usuario>>(emptyList())
        private set
    var usuarioEditar by mutableStateOf<Usuario?>(null)
        private set
    var usuarioEliminar by mutableStateOf<Usuario?>(null)
        private set
    var emailEdit by mutableStateOf("")
        private set
    var nombreEdit by mutableStateOf("")
        private set
    var errorEdit by mutableStateOf<String?>(null)
        private set

    init { cargar() }

    fun cargar() { usuarios = repo.obtenerUsuarios() }


    fun abrirEditar(u: Usuario) {
        usuarioEditar = u
        emailEdit = u.email
        nombreEdit = u.usuario
        errorEdit = null
    }
    fun onEmailEdit(v: String) { emailEdit = v; errorEdit = null }
    fun onNombreEdit(v: String) { nombreEdit = v; errorEdit = null }
    fun cerrarEditar() { usuarioEditar = null }

    fun guardarEdicion() {
        val u = usuarioEditar ?: return
        when {
            emailEdit.isBlank() || nombreEdit.isBlank() ->
                errorEdit = "Completa todos los campos"

            repo.actualizarUsuario(u.id, emailEdit, nombreEdit) -> {
                cargar()
                usuarioEditar = null
            }

            else -> errorEdit = "Ese email ya está en uso"
        }
    }

    fun pedirEliminar(u: Usuario) { usuarioEliminar = u }
    fun cancelarEliminar() { usuarioEliminar = null }

    fun confirmarEliminar() {
        usuarioEliminar?.let {
            repo.eliminarUsuario(it.id)
            cargar()
        }
        usuarioEliminar = null
    }
}