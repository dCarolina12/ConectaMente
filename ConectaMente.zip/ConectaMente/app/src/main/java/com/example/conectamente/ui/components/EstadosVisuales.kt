package com.example.conectamente.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.conectamente.ui.theme.*

@Composable
fun PantallaCargando(mensaje: String = "Cargando...") {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(color = Azul)
        Spacer(Modifier.height(14.dp))
        Text(mensaje, color = GrisTexto, fontSize = 15.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun PantallaError(mensaje: String, onReintentar: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("😕", fontSize = 52.sp)
        Spacer(Modifier.height(8.dp))
        Text("Algo salió mal", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextoOscuro)
        Spacer(Modifier.height(6.dp))
        Text(mensaje, color = GrisTexto, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        BotonPrincipal("Reintentar", onReintentar)
    }
}