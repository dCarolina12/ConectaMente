package com.example.conectamente.viewmodel


import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.example.conectamente.data.model.Partida
import com.example.conectamente.data.repository.AppRepository

class ResultadosViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository.get(app)

    var partidas by mutableStateOf<List<Partida>>(emptyList())
        private set
    var animos by mutableStateOf<Map<String, Int>>(emptyMap())
        private set

    init { cargar() }

    fun cargar() {
        partidas = repo.obtenerPartidas()
        animos = repo.contarAnimos()
    }

    val totalAnimos: Int get() = animos.values.sum()
    val mejorTiempo: Int? get() = partidas.minOfOrNull { it.segundos }
    val menosIntentos: Int? get() = partidas.minOfOrNull { it.intentos }
}