package com.example.conectamente.data.remote

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitInstance {

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private var urlActual = ""
    private var apiActual: ConectaApi? = null

    @Synchronized
    fun api(urlBase: String): ConectaApi {
        val existente = apiActual
        if (existente != null && urlBase == urlActual) return existente

        val nueva = Retrofit.Builder()
            .baseUrl(urlBase)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ConectaApi::class.java)

        urlActual = urlBase
        apiActual = nueva
        return nueva
    }
}