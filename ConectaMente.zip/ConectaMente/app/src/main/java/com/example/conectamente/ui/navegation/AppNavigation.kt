package com.example.conectamente.ui.navegation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.conectamente.ui.screens.*

object Rutas {
    const val LOGIN = "login"
    const val REGISTRO = "registro"
    const val ADMIN = "admin"
    const val HOME = "home"
    const val MEMORIA = "memoria"
    const val RESULTADOS = "resultados"
    const val ANIMO = "animo"
    const val CONTACTAR = "contactar"
    const val LLAMAR = "llamar"
    const val VIDEOLLAMADA = "videollamada"
    const val CONFIGURACION = "configuracion"

    const val NUBE = "nube"

    const val USUARIOS_NUBE = "usuarios_nube"
}

@Composable
fun AppNavigation(haySesion: Boolean) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = if (haySesion) Rutas.HOME else Rutas.LOGIN
    ) {
        composable(Rutas.LOGIN) { PantallaLogin(navController) }
        composable(Rutas.REGISTRO) { PantallaRegistro(navController) }
        composable(Rutas.ADMIN) { PantallaAdmin(navController) }
        composable(Rutas.HOME) { PantallaHome(navController) }
        composable(Rutas.MEMORIA) { PantallaMemoria(navController) }
        composable(Rutas.RESULTADOS) { PantallaResultados(navController) }
        composable(Rutas.ANIMO) { PantallaAnimo(navController) }
        composable(Rutas.CONTACTAR) { PantallaContactar(navController) }
        composable(Rutas.LLAMAR) { PantallaContactos(navController, esVideo = false) }
        composable(Rutas.VIDEOLLAMADA) { PantallaContactos(navController, esVideo = true) }
        composable(Rutas.CONFIGURACION) { PantallaConfiguracion(navController) }
        composable(Rutas.NUBE) { PantallaNube(navController) }
        composable(Rutas.USUARIOS_NUBE) { PantallaUsuariosNube(navController) }
    }
}