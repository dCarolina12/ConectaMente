package com.example.conectamente.data.local

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.conectamente.data.model.Partida
import com.example.conectamente.data.model.Usuario
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.example.conectamente.data.model.Contacto
import com.example.conectamente.data.model.AnimoGuardado

class BaseDatosHelper(context: Context) :
    SQLiteOpenHelper(context, "app_usuarios.db", null, 3) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL UNIQUE,
                usuario TEXT NOT NULL,
                password TEXT NOT NULL
            )
            """.trimIndent()
        )
        crearTablasJuego(db)
        crearTablaContactos(db)
    }


    private fun crearTablasJuego(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS partidas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL,
                intentos INTEGER NOT NULL,
                segundos INTEGER NOT NULL,
                fecha TEXT NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS animos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL,
                estado TEXT NOT NULL,
                fecha TEXT NOT NULL
            )
            """.trimIndent()
        )
    }

    private fun crearTablaContactos(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS contactos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL,
                nombre TEXT NOT NULL,
                telefono TEXT NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) crearTablasJuego(db)
        if (oldVersion < 3) crearTablaContactos(db)
    }

    private fun fechaActual(): String =
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())


    fun registrarUsuario(email: String, usuario: String, password: String): Boolean {
        val valores = ContentValues().apply {
            put("email", email.trim().lowercase())
            put("usuario", usuario.trim())
            put("password", password)
        }
        return writableDatabase.insert("usuarios", null, valores) != -1L
    }

    fun validarLogin(email: String, password: String): Boolean {
        val cursor = readableDatabase.rawQuery(
            "SELECT id FROM usuarios WHERE email = ? AND password = ?",
            arrayOf(email.trim().lowercase(), password)
        )
        val existe = cursor.moveToFirst()
        cursor.close()
        return existe
    }

    fun obtenerNombre(email: String): String {
        val cursor = readableDatabase.rawQuery(
            "SELECT usuario FROM usuarios WHERE email = ?",
            arrayOf(email.trim().lowercase())
        )
        val nombre = if (cursor.moveToFirst()) cursor.getString(0) else ""
        cursor.close()
        return nombre
    }

    fun obtenerUsuarios(): List<Usuario> {
        val lista = mutableListOf<Usuario>()
        val cursor = readableDatabase.rawQuery(
            "SELECT id, email, usuario FROM usuarios ORDER BY id DESC", null
        )
        if (cursor.moveToFirst()) {
            do {
                lista.add(
                    Usuario(
                        id = cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                        email = cursor.getString(cursor.getColumnIndexOrThrow("email")),
                        usuario = cursor.getString(cursor.getColumnIndexOrThrow("usuario"))
                    )
                )
            } while (cursor.moveToNext())
        }
        cursor.close()
        return lista
    }

    fun actualizarUsuario(id: Int, email: String, usuario: String): Boolean {
        val valores = ContentValues().apply {
            put("email", email.trim().lowercase())
            put("usuario", usuario.trim())
        }
        val filas = writableDatabase.updateWithOnConflict(
            "usuarios", valores, "id = ?", arrayOf(id.toString()),
            SQLiteDatabase.CONFLICT_IGNORE
        )
        return filas > 0
    }

    fun eliminarUsuario(id: Int): Boolean {
        return writableDatabase.delete("usuarios", "id = ?", arrayOf(id.toString())) > 0
    }


    fun guardarPartida(email: String, intentos: Int, segundos: Int) {
        val valores = ContentValues().apply {
            put("email", email)
            put("intentos", intentos)
            put("segundos", segundos)
            put("fecha", fechaActual())
        }
        writableDatabase.insert("partidas", null, valores)
    }

    fun obtenerPartidas(email: String): List<Partida> {
        val lista = mutableListOf<Partida>()
        val cursor = readableDatabase.rawQuery(
            "SELECT id, intentos, segundos, fecha FROM partidas WHERE email = ? ORDER BY id DESC",
            arrayOf(email)
        )
        if (cursor.moveToFirst()) {
            do {
                lista.add(Partida(cursor.getInt(0), cursor.getInt(1), cursor.getInt(2), cursor.getString(3)))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return lista
    }


    fun guardarAnimo(email: String, estado: String) {
        val valores = ContentValues().apply {
            put("email", email)
            put("estado", estado)
            put("fecha", fechaActual())
        }
        writableDatabase.insert("animos", null, valores)
    }

    fun contarAnimos(email: String): Map<String, Int> {
        val mapa = mutableMapOf<String, Int>()
        val cursor = readableDatabase.rawQuery(
            "SELECT estado, COUNT(*) FROM animos WHERE email = ? GROUP BY estado",
            arrayOf(email)
        )
        if (cursor.moveToFirst()) {
            do { mapa[cursor.getString(0)] = cursor.getInt(1) } while (cursor.moveToNext())
        }
        cursor.close()
        return mapa
    }
    fun agregarContacto(email: String, nombre: String, telefono: String): Boolean {
        val valores = ContentValues().apply {
            put("email", email)
            put("nombre", nombre.trim())
            put("telefono", telefono.trim())
        }
        return writableDatabase.insert("contactos", null, valores) != -1L
    }

    fun obtenerContactos(email: String): List<Contacto> {
        val lista = mutableListOf<Contacto>()
        val cursor = readableDatabase.rawQuery(
            "SELECT id, nombre, telefono FROM contactos WHERE email = ? ORDER BY nombre COLLATE NOCASE",
            arrayOf(email)
        )
        if (cursor.moveToFirst()) {
            do {
                lista.add(Contacto(cursor.getInt(0), cursor.getString(1), cursor.getString(2)))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return lista
    }

    fun actualizarContacto(id: Int, nombre: String, telefono: String): Boolean {
        val valores = ContentValues().apply {
            put("nombre", nombre.trim())
            put("telefono", telefono.trim())
        }
        return writableDatabase.update("contactos", valores, "id = ?", arrayOf(id.toString())) > 0
    }


    fun eliminarContacto(id: Int): Boolean {
        return writableDatabase.delete("contactos", "id = ?", arrayOf(id.toString())) > 0
    }

    fun borrarHistorial(email: String) {
        writableDatabase.delete("partidas", "email = ?", arrayOf(email))
        writableDatabase.delete("animos", "email = ?", arrayOf(email))
    }
    fun obtenerAnimos(email: String): List<AnimoGuardado> {
        val lista = mutableListOf<AnimoGuardado>()
        val cursor = readableDatabase.rawQuery(
            "SELECT estado, fecha FROM animos WHERE email = ? ORDER BY id DESC",
            arrayOf(email)
        )
        if (cursor.moveToFirst()) {
            do { lista.add(AnimoGuardado(cursor.getString(0), cursor.getString(1))) } while (cursor.moveToNext())
        }
        cursor.close()
        return lista
    }
}