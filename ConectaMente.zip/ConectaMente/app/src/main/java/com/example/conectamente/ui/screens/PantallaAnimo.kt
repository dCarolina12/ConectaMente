package com.example.conectamente.ui.screens

import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.conectamente.data.model.LISTA_ANIMOS
import com.example.conectamente.data.model.TipoAnimo
import com.example.conectamente.ui.components.*
import com.example.conectamente.ui.navegation.Rutas
import com.example.conectamente.ui.theme.*
import com.example.conectamente.viewmodel.AnimoViewModel

@Composable
fun PantallaAnimo(navController: NavController, vm: AnimoViewModel = viewModel()) {
    val context = LocalContext.current

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            BarraSuperior(
                titulo = "Registra tu estado de ánimo",
                onAtras = { navController.popBackStack() },
                containerColor = Color.Transparent,
                contentColor = TextoOscuro
            )
        },
        modifier = Modifier.background(Brush.verticalGradient(listOf(RosaAnimo, RosaClaro)))
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Text("¿Cómo te sientes hoy?", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextoOscuro)

            LISTA_ANIMOS.chunked(3).forEach { fila ->
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    fila.forEach { animo ->
                        OpcionAnimo(
                            animo = animo,
                            seleccionado = vm.seleccion == animo,
                            onClick = { vm.seleccionar(animo) }
                        )
                    }
                }
            }

            Text(
                text = vm.seleccion?.let { "Me siento ${it.etiqueta.lowercase()} ${it.emoji}" }
                    ?: "Toca una carita para elegir",
                color = TextoOscuro,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )

            FraseCard("Tu bienestar es lo más importante. Regálate un minuto para registrar tu ánimo y seguir sumando momentos felices.")

            BotonPrincipal("Guardar mi ánimo") {
                if (vm.guardar()) {
                    Toast.makeText(context, "¡Gracias por compartir cómo te sientes! 💙", Toast.LENGTH_LONG).show()
                    navController.popBackStack(Rutas.HOME, false)
                } else {
                    Toast.makeText(context, "Elige cómo te sientes", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}

@Composable
private fun OpcionAnimo(animo: TipoAnimo, seleccionado: Boolean, onClick: () -> Unit) {
    val escala by animateFloatAsState(if (seleccionado) 1.12f else 1f, label = "escala")

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.scale(escala).clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(88.dp)
                .background(Color.White, CircleShape)
                .then(if (seleccionado) Modifier.border(4.dp, Azul, CircleShape) else Modifier),
            contentAlignment = Alignment.Center
        ) {
            Text(animo.emoji, fontSize = 44.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            animo.etiqueta,
            color = TextoOscuro,
            fontSize = 14.sp,
            fontWeight = if (seleccionado) FontWeight.Bold else FontWeight.Medium
        )
    }
}