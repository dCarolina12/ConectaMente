package com.example.conectamente.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.conectamente.ui.components.*
import com.example.conectamente.ui.theme.*
import com.example.conectamente.viewmodel.ConfiguracionViewModel
import com.example.conectamente.ui.components.AlertDialog

@Composable
fun PantallaConfiguracion(navController: NavController, vm: ConfiguracionViewModel = viewModel()) {
    val context = LocalContext.current

    Scaffold(
        containerColor = Color.Transparent,
        topBar = { BarraSuperior("Configuración", onAtras = { navController.popBackStack() }) },
        modifier = Modifier.background(Brush.verticalGradient(listOf(AmarilloClaro, Color.White)))
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
           
            Surface(shape = RoundedCornerShape(20.dp), color = Color.White, shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(56.dp).background(Azul, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            vm.nombre.firstOrNull()?.uppercase() ?: "?",
                            color = Color.White, fontWeight = FontWeight.Bold, fontSize = 24.sp
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(vm.nombre.ifBlank { "Usuario" }, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextoOscuro)
                        Text(vm.email, color = GrisTexto, fontSize = 13.sp)
                    }
                }
            }

            Titulo("Accesibilidad")
            FilaSwitch(
                titulo = "Letra grande",
                descripcion = "Aumenta el tamaño de los textos en toda la app",
                marcado = vm.textoGrande,
                onCambio = vm::onTextoGrande
            )

            Titulo("Llamadas")
            FilaSwitch(
                titulo = "Confirmar antes de llamar",
                descripcion = "Te pregunta antes de llamar o hacer una videollamada",
                marcado = vm.confirmarLlamada,
                onCambio = vm::onConfirmarLlamada
            )

            Titulo("Mis datos")
            OutlinedButton(
                onClick = vm::pedirBorrar,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text("🗑️  Borrar mi historial de juegos y ánimo", color = Color(0xFFD64545), fontWeight = FontWeight.SemiBold)
            }
        }
    }

    if (vm.mostrarDialogoBorrar) {
        AlertDialog(
            onDismissRequest = vm::cancelarBorrar,
            title = { Text("Borrar historial") },
            text = { Text("Se eliminarán tus partidas y tus registros de ánimo. Esta acción no se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.confirmarBorrar {
                        Toast.makeText(context, "Historial borrado", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Borrar", color = Color(0xFFD64545)) }
            },
            dismissButton = { TextButton(onClick = vm::cancelarBorrar) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun Titulo(texto: String) {
    Text(texto, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = GrisTexto)
}

@Composable
private fun FilaSwitch(
    titulo: String,
    descripcion: String,
    marcado: Boolean,
    onCambio: (Boolean) -> Unit
) {
    Surface(shape = RoundedCornerShape(16.dp), color = Color.White, shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(titulo, fontWeight = FontWeight.Bold, color = TextoOscuro, fontSize = 16.sp)
                Text(descripcion, color = GrisTexto, fontSize = 13.sp)
            }
            Spacer(Modifier.width(10.dp))
            Switch(
                checked = marcado,
                onCheckedChange = onCambio,
                colors = SwitchDefaults.colors(checkedTrackColor = Azul)
            )
        }
    }
}