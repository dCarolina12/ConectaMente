package com.example.conectamente.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.example.conectamente.data.repository.AppRepository

class HomeViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository.get(app)

    val nombre: String = repo.nombreActual()

    var mostrarDialogoSalir by mutableStateOf(false)
        private set

    fun pedirCerrarSesion() { mostrarDialogoSalir = true }
    fun cancelarCerrarSesion() { mostrarDialogoSalir = false }

    fun confirmarCerrarSesion(onListo: () -> Unit) {
        mostrarDialogoSalir = false
        repo.cerrarSesion()
        onListo()
    }
}