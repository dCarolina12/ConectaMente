package com.example.conectamente.data.repository

import android.content.Context
import com.example.conectamente.data.local.ServidorPrefs
import com.example.conectamente.data.model.AnimoRemoto
import com.example.conectamente.data.model.HistorialRemoto
import com.example.conectamente.data.model.PartidaRemota
import com.example.conectamente.data.model.PerfilRemoto
import com.example.conectamente.data.model.SincronizarRequest
import com.example.conectamente.data.model.SincronizarResponse
import com.example.conectamente.data.model.UsuarioRemoto
import com.example.conectamente.data.remote.ConectaApi
import com.example.conectamente.data.remote.RetrofitInstance
import com.google.gson.JsonParseException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class ApiException(message: String, val codigo: Int? = null) : Exception(message)

class NubeRepository(context: Context) {

    private val local = AppRepository.get(context)
    private val servidor = ServidorPrefs(context.applicationContext)

    fun direccion(): String = servidor.direccion()
    fun guardarDireccion(valor: String) = servidor.guardar(valor)

    private fun api(): ConectaApi =
        try {
            RetrofitInstance.api(servidor.urlBase())
        } catch (e: IllegalArgumentException) {
            throw ApiException("La dirección del servidor no es válida")
        }

    suspend fun sincronizar(): SincronizarResponse {
        val email = local.emailActual()
        if (email.isBlank()) throw ApiException("Inicia sesión con un usuario para sincronizar")

        val peticion = withContext(Dispatchers.IO) {
            SincronizarRequest(
                email = email,
                usuario = local.nombreActual().ifBlank { email.substringBefore("@") },
                partidas = local.obtenerPartidas().map {
                    PartidaRemota(intentos = it.intentos, segundos = it.segundos, fecha = it.fecha)
                },
                animos = local.obtenerAnimos().map {
                    AnimoRemoto(estado = it.estado, fecha = it.fecha)
                }
            )
        }
        return llamar { api().sincronizar(peticion) }
    }

    suspend fun historial(): HistorialRemoto {
        val email = local.emailActual()
        if (email.isBlank()) throw ApiException("Inicia sesión con un usuario para ver tu historial")

        val perfil = try {
            consultarUsuario(email)
        } catch (e: ApiException) {
            if (e.message == USUARIO_NO_ENCONTRADO) null else throw e
        }
        if (perfil == null) return HistorialRemoto(null, emptyList(), emptyList())

        val partidas = llamar { api().listarPartidas(email) }
        val animos = llamar { api().listarAnimos(email) }
        return HistorialRemoto(perfil, partidas, animos)
    }

    suspend fun consultarUsuario(email: String): PerfilRemoto =
        llamar { api().consultarUsuario(email.trim().lowercase()) }

    suspend fun listarUsuarios(): List<UsuarioRemoto> =
        llamar { api().listarUsuarios() }

    private suspend fun <T> llamar(bloque: suspend () -> T): T {
        try {
            return bloque()
        } catch (e: CancellationException) {
            throw e
        } catch (e: ApiException) {
            throw e
        } catch (e: UnknownHostException) {
            throw ApiException("No se encontró el servidor. Revisa la dirección")
        } catch (e: ConnectException) {
            throw ApiException("No se pudo conectar. ¿Está encendido Apache en XAMPP? Revisa la dirección del servidor")
        } catch (e: SocketTimeoutException) {
            throw ApiException("El servidor no respondió a tiempo. Revisa que XAMPP esté encendido y que la dirección sea correcta")
        } catch (e: IOException) {
            throw ApiException("Problema de red. Revisa tu conexión")
        } catch (e: HttpException) {
            val cuerpo = try { e.response()?.errorBody()?.string().orEmpty() } catch (x: Exception) { "" }
            val delServidor = Regex("\"mensaje\"\\s*:\\s*\"([^\"]+)\"").find(cuerpo)?.groupValues?.get(1)
            val texto = delServidor ?: when (e.code()) {
                404 -> "No se encontró el servicio. Revisa que la carpeta «conectamente» esté en htdocs"
                in 500..599 -> "El servidor tiene problemas. Revisa que Apache y MySQL estén encendidos"
                else -> "Error del servidor (${e.code()})"
            }
            throw ApiException(texto, e.code())
        } catch (e: JsonParseException) {
            throw ApiException("La respuesta del servidor no es válida")
        } catch (e: Exception) {
            throw ApiException("Ocurrió un error inesperado")
        }
    }

    companion object {
        const val USUARIO_NO_ENCONTRADO = "Usuario no encontrado"
    }
}