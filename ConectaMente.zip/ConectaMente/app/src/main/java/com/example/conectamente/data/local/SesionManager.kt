package com.example.conectamente.data.local

import android.content.Context

class SesionManager(context: Context) {

    private val prefs = context.getSharedPreferences("sesion", Context.MODE_PRIVATE)

    fun guardarSesion(email: String, nombre: String) {
        prefs.edit()
            .putString("email", email.trim().lowercase())
            .putString("nombre", nombre)
            .putBoolean("sesion_activa", true)
            .apply()
    }

    fun haySesion(): Boolean = prefs.getBoolean("sesion_activa", false)

    fun emailActual(): String = prefs.getString("email", "") ?: ""

    fun nombreActual(): String = prefs.getString("nombre", "") ?: ""

    fun cerrarSesion() {
        prefs.edit()
            .remove("email")
            .remove("nombre")
            .putBoolean("sesion_activa", false)
            .apply()
    }

    fun recordarEmail(email: String) {
        prefs.edit().putString("email_recordado", email.trim().lowercase()).apply()
    }

    fun olvidarEmail() {
        prefs.edit().remove("email_recordado").apply()
    }

    fun emailRecordado(): String = prefs.getString("email_recordado", "") ?: ""
    fun textoGrande(): Boolean = prefs.getBoolean("texto_grande", false)

    fun guardarTextoGrande(valor: Boolean) {
        prefs.edit().putBoolean("texto_grande", valor).apply()
    }

    fun confirmarLlamada(): Boolean = prefs.getBoolean("confirmar_llamada", true)

    fun guardarConfirmarLlamada(valor: Boolean) {
        prefs.edit().putBoolean("confirmar_llamada", valor).apply()
    }
}