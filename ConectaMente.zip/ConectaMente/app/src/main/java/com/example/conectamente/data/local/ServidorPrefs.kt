package com.example.conectamente.data.local

import android.content.Context

class ServidorPrefs(context: Context) {

    private val prefs = context.getSharedPreferences("servidor", Context.MODE_PRIVATE)


    fun direccion(): String = prefs.getString("direccion", DIRECCION_EMULADOR) ?: DIRECCION_EMULADOR

    fun guardar(valor: String) {
        val limpia = limpiar(valor)
        prefs.edit().putString("direccion", limpia.ifEmpty { DIRECCION_EMULADOR }).apply()
    }

    fun urlBase(): String = "http://${direccion()}/"

    private fun limpiar(valor: String): String =
        valor.trim()
            .removePrefix("http://")
            .removePrefix("https://")
            .trimEnd('/')

    companion object {
        const val DIRECCION_EMULADOR = "10.0.2.2"
    }
}