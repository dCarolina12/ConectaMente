package com.example.conectamente.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.conectamente.data.repository.AppRepository
import kotlinx.coroutines.flow.StateFlow

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = AppRepository.get(app)

    val haySesion: Boolean = repo.haySesion()

    val textoGrande: StateFlow<Boolean> = repo.textoGrande
}