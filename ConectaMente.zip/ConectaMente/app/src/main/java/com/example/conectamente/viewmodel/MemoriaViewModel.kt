package com.example.conectamente.viewmodel


import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.conectamente.data.repository.AppRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MemoriaViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository.get(app)
    private val emojis = listOf("🍎", "🐶", "🌻", "⚽")

    var cartas by mutableStateOf(nuevoTablero())
        private set
    val volteadas = mutableStateListOf<Int>()
    val encontradas = mutableStateListOf<Int>()
    var intentos by mutableIntStateOf(0)
        private set
    var segundos by mutableIntStateOf(0)
        private set
    var terminado by mutableStateOf(false)
        private set

    private var bloqueado = false
    private var cronometro: Job? = null

    init { iniciarCronometro() }

    private fun nuevoTablero() = (emojis + emojis).shuffled()

    private fun iniciarCronometro() {
        cronometro?.cancel()
        cronometro = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (!terminado) segundos++
            }
        }
    }

    fun reiniciar() {
        cartas = nuevoTablero()
        volteadas.clear()
        encontradas.clear()
        intentos = 0
        segundos = 0
        terminado = false
        bloqueado = false
        iniciarCronometro()
    }

    fun onCartaTocada(i: Int) {
        if (bloqueado || terminado || volteadas.size >= 2 || i in volteadas || i in encontradas) return
        volteadas.add(i)

        if (volteadas.size == 2) {
            intentos++
            val a = volteadas[0]
            val b = volteadas[1]
            viewModelScope.launch {
                bloqueado = true
                if (cartas[a] == cartas[b]) {
                    delay(300)
                    encontradas.add(a)
                    encontradas.add(b)
                } else {
                    delay(800)
                }
                volteadas.clear()
                bloqueado = false

                if (encontradas.size == cartas.size) {
                    terminado = true
                    repo.guardarPartida(intentos, segundos)   // SQLite
                }
            }
        }
    }
}