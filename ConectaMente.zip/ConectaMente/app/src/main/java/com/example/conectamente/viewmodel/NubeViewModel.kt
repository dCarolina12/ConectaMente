package com.example.conectamente.viewmodel


import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.conectamente.data.model.HistorialRemoto
import com.example.conectamente.data.model.SincronizarResponse
import com.example.conectamente.data.repository.ApiException
import com.example.conectamente.data.repository.NubeRepository
import com.example.conectamente.utils.NetworkUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class NubeViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = NubeRepository(app)

    var direccion by mutableStateOf(repo.direccion())
        private set

    var historial by mutableStateOf<UiState<HistorialRemoto>>(UiState.Idle)
        private set

    var sincronizacion by mutableStateOf<UiState<SincronizarResponse>>(UiState.Idle)
        private set

    private var trabajo: Job? = null

    init { cargarHistorial() }

    fun onDireccionChange(valor: String) { direccion = valor }

    fun guardarDireccion() {
        repo.guardarDireccion(direccion)
        direccion = repo.direccion()
        sincronizacion = UiState.Idle
        cargarHistorial()
    }

    fun cargarHistorial() {
        trabajo?.cancel()

        if (!NetworkUtils.hayConexion(getApplication())) {
            historial = UiState.Error("Sin conexión. Activa el WiFi o los datos e inténtalo de nuevo.")
            return
        }

        trabajo = viewModelScope.launch {
            historial = UiState.Loading
            try {
                historial = UiState.Success(repo.historial())
            } catch (e: ApiException) {
                historial = UiState.Error(e.message ?: "Ocurrió un error")
            }
        }
    }

    fun sincronizar() {
        if (sincronizacion is UiState.Loading) return

        if (!NetworkUtils.hayConexion(getApplication())) {
            sincronizacion = UiState.Error("Sin conexión. Activa el WiFi o los datos e inténtalo de nuevo.")
            return
        }

        viewModelScope.launch {
            sincronizacion = UiState.Loading
            try {
                sincronizacion = UiState.Success(repo.sincronizar())
                cargarHistorial()
            } catch (e: ApiException) {
                sincronizacion = UiState.Error(e.message ?: "Ocurrió un error")
            }
        }
    }
}