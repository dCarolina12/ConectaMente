package com.example.conectamente.viewmodel

import android.app.Application
import android.util.Patterns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.example.conectamente.data.repository.AppRepository

class RegistroViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository.get(app)

    var email by mutableStateOf("")
        private set
    var usuario by mutableStateOf("")
        private set
    var password by mutableStateOf("")
        private set
    var verPassword by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    fun onEmailChange(v: String) { email = v; error = null }
    fun onUsuarioChange(v: String) { usuario = v; error = null }
    fun onPasswordChange(v: String) { password = v; error = null }
    fun onVerPasswordChange(v: Boolean) { verPassword = v }

    fun registrar(onExito: () -> Unit) {
        when {
            email.isBlank() || usuario.isBlank() || password.isBlank() ->
                error = "Completa todos los campos"

            !Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() ->
                error = "El email no es válido"

            password.length < 6 ->
                error = "La contraseña debe tener mínimo 6 caracteres"

            repo.registrarUsuario(email, usuario, password) ->
                onExito()

            else -> error = "Ese email ya está registrado"
        }
    }
}