package com.example.conectamente.data.remote

import com.example.conectamente.data.model.AnimoRemoto
import com.example.conectamente.data.model.PartidaRemota
import com.example.conectamente.data.model.PerfilRemoto
import com.example.conectamente.data.model.SincronizarRequest
import com.example.conectamente.data.model.SincronizarResponse
import com.example.conectamente.data.model.UsuarioRemoto
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface ConectaApi {


    @POST("conectamente/sincronizar.php")
    suspend fun sincronizar(@Body datos: SincronizarRequest): SincronizarResponse

    @GET("conectamente/listar_usuarios.php")
    suspend fun listarUsuarios(): List<UsuarioRemoto>

    @GET("conectamente/consultar_usuario.php")
    suspend fun consultarUsuario(@Query("email") email: String): PerfilRemoto

    @GET("conectamente/listar_partidas.php")
    suspend fun listarPartidas(@Query("email") email: String): List<PartidaRemota>

    @GET("conectamente/listar_animos.php")
    suspend fun listarAnimos(@Query("email") email: String): List<AnimoRemoto>
}