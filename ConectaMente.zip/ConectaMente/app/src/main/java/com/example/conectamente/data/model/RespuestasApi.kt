package com.example.conectamente.data.model

import com.google.gson.annotations.SerializedName

data class SincronizarRequest(
    val email: String,
    val usuario: String,
    val partidas: List<PartidaRemota>,
    val animos: List<AnimoRemoto>
)

data class SincronizarResponse(
    val ok: Boolean,
    val mensaje: String,
    @SerializedName("partidas_nuevas") val partidasNuevas: Int,
    @SerializedName("animos_nuevos") val animosNuevos: Int
)

data class UsuarioRemoto(
    val id: Int,
    val email: String,
    val usuario: String,
    val partidas: Int,
    val animos: Int
)

data class PerfilRemoto(
    val id: Int,
    val email: String,
    val usuario: String,
    @SerializedName("total_partidas") val totalPartidas: Int,
    @SerializedName("mejor_tiempo") val mejorTiempo: Int?,
    @SerializedName("menos_intentos") val menosIntentos: Int?,
    @SerializedName("total_animos") val totalAnimos: Int,
    @SerializedName("ultimo_animo") val ultimoAnimo: String?
)

data class PartidaRemota(
    val id: Int = 0,
    val intentos: Int,
    val segundos: Int,
    val fecha: String
)

data class AnimoRemoto(
    val id: Int = 0,
    val estado: String,
    val fecha: String
)

data class AnimoGuardado(
    val estado: String,
    val fecha: String
)

data class HistorialRemoto(
    val perfil: PerfilRemoto?,
    val partidas: List<PartidaRemota>,
    val animos: List<AnimoRemoto>
)