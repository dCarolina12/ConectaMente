package com.example.conectamente.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.conectamente.ui.components.*
import com.example.conectamente.ui.theme.*
import com.example.conectamente.viewmodel.AdminViewModel
import androidx.compose.material.icons.filled.Cloud
import com.example.conectamente.ui.navegation.Rutas
import com.example.conectamente.ui.components.AlertDialog

@Composable
fun PantallaAdmin(navController: NavController, vm: AdminViewModel = viewModel()) {

    Scaffold(
        containerColor = AzulClaro,
        topBar = {
            BarraSuperior(
                titulo = "Usuarios registrados (${vm.usuarios.size})",
                onAtras = { navController.popBackStack() }
            ) {
                IconButton(onClick = { navController.navigate(Rutas.USUARIOS_NUBE) }) {
                    Icon(Icons.Default.Cloud, contentDescription = "Usuarios en el servidor")
                }
            }
        }
    ) { padding ->
        if (vm.usuarios.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("Aún no hay usuarios registrados", color = GrisTexto)
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(vm.usuarios, key = { it.id }) { u ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.size(46.dp).background(Azul, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(u.usuario.first().uppercase(), color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(u.usuario, fontWeight = FontWeight.Bold, color = TextoOscuro)
                                Text(u.email, color = GrisTexto, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { vm.abrirEditar(u) }) {
                                Icon(Icons.Default.Edit, contentDescription = "Editar", tint = Azul)
                            }
                            IconButton(onClick = { vm.pedirEliminar(u) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = Color(0xFFD64545))
                            }
                        }
                    }
                }
            }
        }
    }

    if (vm.usuarioEditar != null) {
        AlertDialog(
            onDismissRequest = vm::cerrarEditar,
            title = { Text("Editar usuario") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    CampoTexto(vm.emailEdit, vm::onEmailEdit, "Email", Icons.Default.Email)
                    CampoTexto(vm.nombreEdit, vm::onNombreEdit, "Usuario", Icons.Default.Person)
                    vm.errorEdit?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = { TextButton(onClick = vm::guardarEdicion) { Text("Guardar") } },
            dismissButton = { TextButton(onClick = vm::cerrarEditar) { Text("Cancelar") } }
        )
    }

    vm.usuarioEliminar?.let { u ->
        AlertDialog(
            onDismissRequest = vm::cancelarEliminar,
            title = { Text("Eliminar usuario") },
            text = { Text("¿Seguro que quieres eliminar a ${u.usuario}? Esta acción no se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = vm::confirmarEliminar) {
                    Text("Eliminar", color = Color(0xFFD64545))
                }
            },
            dismissButton = { TextButton(onClick = vm::cancelarEliminar) { Text("Cancelar") } }
        )
    }
}