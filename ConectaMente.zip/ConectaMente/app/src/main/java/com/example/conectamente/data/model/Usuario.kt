package com.example.conectamente.data.model

data class Usuario(
    val id: Int,
    val email: String,
    val usuario: String
)