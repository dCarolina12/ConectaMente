package com.example.conectamente.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.conectamente.ui.navegation.Rutas
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.conectamente.ui.components.*
import com.example.conectamente.ui.theme.*
import com.example.conectamente.viewmodel.MemoriaViewModel
import com.example.conectamente.ui.components.AlertDialog

@Composable
fun PantallaMemoria(navController: NavController, vm: MemoriaViewModel = viewModel()) {

    fun irAResultados() {
        navController.navigate(Rutas.RESULTADOS) {
            popUpTo(Rutas.MEMORIA) { inclusive = true }
        }
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = { BarraSuperior("Juegos de memoria", onAtras = { navController.popBackStack() }) },
        modifier = Modifier.background(Brush.verticalGradient(listOf(AzulClaro, Color.White)))
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ChipDato("🎯 Intentos: ${vm.intentos}", Modifier.weight(1f))
                ChipDato("⏱️ ${formatoTiempo(vm.segundos)}", Modifier.weight(1f))
            }

            Text("Encuentra las parejas", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextoOscuro)

            // Tablero 4 x 2
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                vm.cartas.chunked(4).forEachIndexed { fila, grupo ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        grupo.forEachIndexed { col, emoji ->
                            val i = fila * 4 + col
                            CartaMemoria(
                                emoji = emoji,
                                volteada = i in vm.volteadas,
                                encontrada = i in vm.encontradas,
                                modifier = Modifier.weight(1f)
                            ) { vm.onCartaTocada(i) }
                        }
                    }
                }
            }

            TextButton(onClick = vm::reiniciar, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("🔄 Reiniciar juego", color = Azul, fontWeight = FontWeight.SemiBold)
            }

            FraseCard("El juego mantiene la mente ágil, el corazón joven y el espíritu en constante aprendizaje.")

            BotonPrincipal("Siguiente") { irAResultados() }
        }
    }

    if (vm.terminado) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("¡Muy bien! 🎉") },
            text = { Text("Lo lograste en ${vm.intentos} intentos y ${formatoTiempo(vm.segundos)}.") },
            confirmButton = { TextButton(onClick = vm::reiniciar) { Text("Jugar de nuevo") } },
            dismissButton = { TextButton(onClick = { irAResultados() }) { Text("Ver resultados") } }
        )
    }
}

@Composable
private fun ChipDato(texto: String, modifier: Modifier = Modifier) {
    Surface(shape = RoundedCornerShape(50), color = Color.White, shadowElevation = 2.dp, modifier = modifier) {
        Text(
            texto,
            color = TextoOscuro,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
        )
    }
}

@Composable
private fun CartaMemoria(
    emoji: String,
    volteada: Boolean,
    encontrada: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val fondo = when {
        encontrada -> VerdeClaro
        volteada -> Color.White
        else -> Azul
    }
    Box(
        modifier = modifier
            .aspectRatio(0.75f)
            .clip(RoundedCornerShape(16.dp))
            .background(fondo)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (volteada || encontrada) Text(emoji, fontSize = 34.sp)
        else Text("?", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
    }
}